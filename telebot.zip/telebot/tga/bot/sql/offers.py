import sqlite3
import os
from datetime import datetime, date


class Offers():
  def __init__(self):
    self.db = sqlite3.connect("tga/bot.db")
    self.sql = self.db.cursor()
    print(os.getcwd())
    
  def getOffer(self, id, name):
    self.sql.execute(f"""SELECT * FROM ugc_offers WHERE name == '{name}' and user == {id} and stop > (SELECT date('now'))""")
    result = self.sql.fetchone()
    id = str(result[1])
    names = str(result[2])
    citi = str(result[3])
    theme = str(result[4])
    subs = str(result[5])
    start = str(result[6])
    stop = str(result[7])
    texts = str(result[8])
    res = [id, names, citi, theme, subs, start, stop, texts]
    print(res)
    return res
    
  def getOfferModer(self, id, name):
    self.sql.execute(f"""SELECT * FROM ugc_moder WHERE name == '{name}' and user == {id} and stop > (SELECT date('now'))""")
    result = self.sql.fetchone()
    id = str(result[1])
    names = str(result[2])
    citi = str(result[3])
    theme = str(result[4])
    subs = str(result[5])
    start = str(result[6])
    stop = str(result[7])
    texts = str(result[8])
    res = [id, names, citi, theme, subs, start, stop, texts]
    print(res)
    return res
    
  def selectOffer(self, name):
    self.sql.execute(f"""SELECT * FROM ugc_offers WHERE name == '{name}'""")
    result = self.sql.fetchone()
    user = str(result[1])
    names = str(result[2])
    citi = str(result[3])
    theme = str(result[4])
    subs = str(result[5])
    start = str(result[6])
    stop = str(result[7])[0 : -9]
    texts = str(result[8])
    print(stop)
    if datetime.strptime(stop, '%Y-%m-%d').date() < date.today():
      return 0
    res = [user, names, citi, theme, subs, start, stop, texts]
    print(res)
    return res
    
  def getOfferM(self, id):
    self.sql.execute(f"""SELECT * FROM ugc_moder WHERE rowid == (SELECT MAX(rowid) FROM ugc_moder WHERE user == {id})""")
    result = self.sql.fetchone()
    names = str(result[2])
    citi = str(result[3])
    theme = str(result[4])
    subs = str(result[5])
    start = str(result[6])
    stop = str(result[7])
    texts = str(result[8])
    res = [0, names, citi, theme, subs, start, stop, texts]
    print(res)
    return res
    
  def setName(self, id, name, start, mid):
    self.sql.execute(f"INSERT INTO ugc_moder VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", (id+mid, id, name, 'Пусто', 'Пусто', 'Пусто', start, 'Пусто', 'Пусто', 'Этот оффер еще никто не взял в работу', 0, 0))
    self.db.commit()

    self.sql.execute(f"SELECT rowid FROM ugc_offers WHERE stop > (SELECT date('now'))")
    act_offers = self.sql.fetchall()
    print(act_offers)
    act_offers = len(act_offers)
    self.sql.execute(f"UPDATE ugc_stats SET active_offers = {act_offers} WHERE rowid = (SELECT MAX(rowid) FROM ugc_stats)")

    self.sql.execute(f"SELECT rowid FROM ugc_moder WHERE stop > (SELECT date('now'))")
    moder_offers = len(self.sql.fetchall())
    self.sql.execute(f"UPDATE ugc_stats SET moder_offers = {moder_offers} WHERE rowid = (SELECT MAX(rowid) FROM ugc_stats)")

    self.sql.execute(f"SELECT rowid FROM ugc_offers WHERE stop > (SELECT date('now')) and bloger != 'Этот оффер еще никто не взял в работу' ")
    work_offers = len(self.sql.fetchall())
    self.sql.execute(f"UPDATE ugc_stats SET work_offer = {work_offers} WHERE rowid = (SELECT MAX(rowid) FROM ugc_stats)")
    self.db.commit()
    
  def setOnline(self, id, name, online):
    self.sql.execute(f"""UPDATE ugc_moder SET online = '{online}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setTheme(self, id, name, theme):
    self.sql.execute(f"""UPDATE ugc_moder SET theme = '{theme}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setSubs(self, id, name, subs):
    self.sql.execute(f"""UPDATE ugc_moder SET subs = '{subs}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setStop(self, id, name, stop):
    self.sql.execute(f"""UPDATE ugc_moder SET stop = '{stop}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setText(self, id, name, text):
    self.sql.execute(f"""UPDATE ugc_moder SET text = '{text}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()
    
  def setPromo(self, id, name, promo):
    self.sql.execute(f"""UPDATE ugc_moder SET promo = '{promo}' WHERE user == {id} and name == '{name}' """)
    self.db.commit()

  def getPromo(self, id):
    self.sql.execute(f"SELECT promo FROM ugc_offers WHERE user = {id}")
    promo = str(self.sql.fetchone()).replace('(', '').replace("""'""", "").replace(',', '').replace(')', '')
    return promo
    
  def getName(self, id):
    if id != 0:
      self.sql.execute(f"SELECT name FROM ugc_offers WHERE user = {id} and stop > (SELECT date('now'))")
    else:
      self.sql.execute(f"SELECT name FROM ugc_offers and stop > (SELECT date('now'))")
    names = self.sql.fetchall()
    out = []
    for name in names:
      out.append(name[0])
      
    return out
    
  def getModerName(self, id):
    if id != 0:
      self.sql.execute(f"SELECT name FROM ugc_moder WHERE user = {id}")
    else:
      self.sql.execute(f"SELECT name FROM ugc_moder")
    names = self.sql.fetchall()
    out = []
    for name in names:
      out.append(name[0])
      
    return out
    
  def owner(self, name, id):
    self.sql.execute(f"SELECT user FROM ugc_offers WHERE name = '{name}' and user = {id}")
    if self.sql.fetchone() == None:
      self.sql.execute(f"SELECT user FROM ugc_moder WHERE name = '{name}' and user = {id}")
      if self.sql.fetchone() == None:
        return False
      else:
        return True
        
    else:
      return True
      
  def setBloger(self, name, id, url):
    self.sql.execute(f"""SELECT bloger FROM ugc_offers WHERE user = {id} and name = '{name}'""")
    bloger = str(self.sql.fetchone()).replace('(', '').replace(')', '').replace(",", '').replace("""'""", "")
    text = 'Этот оффер еще никто не взял в работу'
    if bloger == text:
      self.sql.execute(f"""UPDATE ugc_offers SET bloger = '{url}' WHERE user = {id} and name = '{name}' """)
    else:
      url = bloger + ' ' + url
      self.sql.execute(f"""UPDATE ugc_offers SET bloger = '{url}' WHERE user = {id} and name = '{name}' """)

    self.db.commit()
    
  def getWork(self, url):
    self.sql.execute(f"""SELECT * FROM ugc_offers WHERE stop > (SELECT date('now'))""")
    results = self.sql.fetchall()
    res = []
    for result in results:
      bloger = result[9]
      blogers = bloger.split(' ')
      for blog in blogers:
        if blog == url:
          names = str(result[2])
          res.append(names)
        
    return res
    
  def delBloger(self, id, url):
    self.sql.execute(f"""SELECT * FROM ugc_offers WHERE stop > (SELECT date('now'))""")
    results = self.sql.fetchall()
    for result in results:
      bloger = result[9]
      if bloger != url:
        blogers = bloger.split(' ')
        num = blogers.index(url)
        blogers.pop(num)
        text = ''
        for b in blogers:
          text = text + ' ' + b
          self.sql.execute(f"UPDATE ugc_offers SET bloger = '{text}' WHERE user == {id}")
          self.db.commit()
      
      elif bloger == url:
        text = 'Этот оффер еще никто не взял в работу'
        self.sql.execute(f"UPDATE ugc_offers SET bloger = '{text}' WHERE user == {id}")
        self.db.commit()