from aiogram import types

from loader import dp, bot
from sql import AddUsers as au
import os






@dp.message_handler()
async def ban(message: types.Message):
  AU = au()
  user_id = AU.getBan()
  is_banned = False
  for user in user_id:
    user = int(user)
    if user == message.from_user.id:
      await message.answer('За нарушение правил вы были заблокированы! Наш бот внес вас с черный список!')
      is_banned = True
