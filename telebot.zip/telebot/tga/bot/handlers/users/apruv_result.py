from aiogram import types
from aiogram.dispatcher.filters import Command
import datetime

from loader import dp, bot
from keyboards.inline import bloger_menu
from sql import Offers


@dp.callback_query_handler(text='offer_compleeted')
async def apruv_result(c):
  id_oder = c.from_user.id
  await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  offers = Offers()
  id = c.message.text.split()[0] + 'p'
  id = id[1 : -1]
  name = c.message.text.split('\n')[2] + 'p'
  name = name[1 : -1]
  offers.delBloger(c.from_user.id, name)
  promo = offers.getPromo(id_oder)
  await bot.send_message(id, f"Заказчик принял ваш оффер {name}! Вот промокод: \n {promo}")
  
  
@dp.callback_query_handler(text=["reject", "reject_result"])
async def reject_res(c):
  await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  offers = Offers()
  id = c.message.text.split()[0] + 'p'
  id = id[1 : -1]
  name = c.message.text.split('\n')[2] + 'p'
  name = name[1 : -1]
  await bot.send_message(id, f"Oффер {name} отклонён!")
  offers.delBloger(c.from_user.id, name)