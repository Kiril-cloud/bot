from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardButton

from loader import dp, bot
from states import work_st
from keyboards.inline import answer_kb, compleet_kb


@dp.callback_query_handler(text='answer')
async def answer(c):
  await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  w = work_st()
  id = c.message.text.split()[4] + 'p'
  id = id[1 : -1]
  res = InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton(text='Отправить вопрос', callback_data='`' + str(id)))
  await c.message.answer(f'#{id}\n Отправте ваш вопрос(вы можете прекрепить не более 5 файлов), и затем нажмите на кнопку, мы перешлем его заказчику:', reply_markup = res)

 
@dp.callback_query_handler(text='offer_compleet')
async def compleet(c):
  await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  w = work_st()
  id = c.message.text.split()[4] + 'p'
  id = id[1 : -1]
  name = c.message.text[c.message.text.find("Название: ") + 10 : c.message.text.find("Тематика: ")]
  res = InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton(text='Отправить результат', callback_data='|' + str(id)))
  await c.message.answer(f'#{id}\n#{name}\n Отправте фото, видео, аудио или текстовый материал(вы можете прикрепить не более 5 файлов), а затем нажмите на кнопку:', reply_markup = res)