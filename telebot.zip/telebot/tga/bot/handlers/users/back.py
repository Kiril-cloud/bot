from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
from loader import dp, bot
from keyboards.inline import offer, create_offer


@dp.callback_query_handler(text='back')
async def back(c: CallbackQuery, state: FSMContext):
  text = c.message.text
  s = text.find('Пусто')
  if c.data == 'back' and s == -1:
    await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
    await state.finish()
    await c.message.answer('Выберите действие на клавиатуре ниже:', reply_markup = offer)

  else:
    await c.message.answer('Вы заполнили не все поля')
    await c.message.answer(text, reply_markup=create_offer)