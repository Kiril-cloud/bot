from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart
from keyboards.inline import menu

from loader import dp, bot
from sql import AddUsers as au


@dp.message_handler(CommandStart())
async def bot_start(message: types.Message):
  try:
    AU = au()
    ban = AU.getBan()
    await message.answer(f"Привет, {message.from_user.full_name}! Это платформа для рекламодателей и блогеров. Выберите кто вы:", reply_markup=menu)
  except:
    pass
  
