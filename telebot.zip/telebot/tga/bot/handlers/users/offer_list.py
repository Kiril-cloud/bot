from tga.bot.sql import AddUsers
from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
import datetime
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


from loader import dp, bot
from sql import Offers, AddUsers
from keyboards.inline import edit_offers, offer, work_kb
from states import offer_states


offer_state = offer_states()
offers = Offers()

@dp.callback_query_handler(text='list')
async def offer_list(c: CallbackQuery, state: FSMContext):
  await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  offers = Offers()
  
  names = offers.getName(c.from_user.id)
  names_moder = offers.getModerName(c.from_user.id)
  list_offer = InlineKeyboardMarkup(row_width=2)
  
  for name in names:
    name = InlineKeyboardButton(name, callback_data = name)
    list_offer.add(name)
    
  for moder_name in names_moder:
    moder_name = moder_name + '🔧'
    moder_name_bt = InlineKeyboardButton(moder_name, callback_data = moder_name)
    list_offer.add(moder_name_bt)
    
  await c.message.answer('Вот список ваших офферов. Для редактирования нажмите на нужный вам оффер.', reply_markup = list_offer)
  
  

@dp.callback_query_handler()
async def offer_edit(c: CallbackQuery, state: FSMContext):
  AU = AddUsers()
  if c.data[0] == '`':
    try:
      for i in range(1, 6):
        await bot.forward_message(chat_id=int(c.data.replace('`', '')), from_chat_id=c.from_user.id, message_id=c.message.message_id+i)

    except:
      ret = InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton(text='Отправить ответ', callback_data='^' + str(c.from_user.id)))
      await bot.send_message(c.data.replace('`', ''), 'Отправте ответ на вопрос блогера, затем нажмите на кнопку:', reply_markup=ret)

  elif c.data[0] == '|':
    print('|')
    oid = c.from_user.id
    try:
      for i in range(1, 6):
        await bot.forward_message(chat_id=int(c.data.replace('|', '')), from_chat_id=c.from_user.id, message_id=c.message.message_id+i)

    except:
      ret = InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton(text='Принять работy', callback_data=';' + str(oid)), InlineKeyboardButton(text='Отклонить работy', callback_data='!' + str(c.from_user.id)))
      await bot.send_message(c.data.replace('|', ''), 'Работа выполнена?', reply_markup=ret)

  elif c.data[0] == '!':
    ret = InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton(text='Отправить ответ', callback_data=':' + str(c.data.replace('!', ''))))
    await c.message.answer("Напишите почему вы не приняли работу, а затем нажмите на кнопку:", reply_markup=ret)

  elif c.data[0] == ';':
    print(1234567890)
    id_oder = c.from_user.id
    await c.message.edit_text('Вы приняли работу!')
    offers = Offers()
    id = c.data.replace(';', '')
    url = AU.getBloger(id)
    offers.delBloger(id_oder, url)
    promo = offers.getPromo(id_oder)
    await bot.send_message(id, f"Заказчик принял ваш оффер! Вот промокод: \n {promo}")

  elif c.data[0] == ':':
    id_oder = c.from_user.id
    offers = Offers()
    id = c.data.replace(':', '')
    await bot.send_message(id, f"Заказчик отклонил ваш оффер! Исправте недоработки и отправте результат заказчику. Комментарий заказчика:")
    await bot.forward_message(chat_id=id, from_chat_id=id_oder, message_id=c.message.message_id+1)
    await c.message.edit_text('Вы отклонили работу!')

  elif c.data[0] == '^':
    await bot.forward_message(chat_id=int(c.data.replace('^', '')), from_chat_id=c.from_user.id, message_id=c.message.message_id+1)

  else: 
    # await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
    try:
      offers = Offers()
      print(c.from_user.id)
      name = c.data
      if name == 'back':
        await state.finish()
        await c.message.answer('Выберите действие на клавиатуре ниже:', reply_markup = offer)
      else:
        ab = offers.owner(name, c.from_user.id)
        if ab == False:
          ab = offers.owner(name[0 : -1], c.from_user.id)
        if ab == True:
          if name[len(name)-1 : len(name)] == '🔧':
            name = name[0 : -1]
            status = "🔧На модерации"
            
          else:
            status = "Подтверждён"
          try:
            res = offers.getOffer(c.from_user.id, name)
          except:
            res = offers.getOfferModer(c.from_user.id, name)
          name = res[1]
          citi = res[2]
          theme = res[3]
          subs = res[4]
          start = res[5]
          stop = res[6]
          texts = res[7]
          text = f'Название: {name}\n Статус: {status}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
          await c.message.answer(f'Вот ваш оффер: \n {text}', reply_markup=edit_offers)
          
        elif ab == False:
          res = offers.selectOffer(c.data)
          user = res[0]
          name = res[1]
          citi = res[2]
          theme = res[3]
          subs = res[4]
          start = res[5]
          stop = res[6]
          texts = res[7]
          text = f'#{user}\n Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
          await c.message.answer(f'Вот информация по офферу: \n {text}', reply_markup=work_kb)
        
    except Exception as e:
      print(e)