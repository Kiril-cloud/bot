from aiogram import types
from aiogram.dispatcher.filters import Command
import datetime

from loader import dp, bot
from keyboards.inline import bloger_menu
from sql import AddUsers, Offers


@dp.callback_query_handler(text='accept')
async def apruv_offer(c):
  await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  AU = AddUsers()
  offer = Offers()
  bloger_id = str(c.message.text.split()[0]) + 'p'
  bloger_id = bloger_id[1 : -1]
  bloger_name = str(c.message.text.split()[2]) + 'p'
  bloger_name = bloger_name[1 : -1]
  
  id_ads = str(c.message.text.split()[9]) + 'p'
  id_ads = int(id_ads[1 : -1])
  
  name = str(c.message.text.split()[1]) + 'p'
  name = name[1 : -1]
  print(id_ads, name)
  
  offer.setBloger(name, id_ads, bloger_name)
  await bot.send_message(bloger_id, 'Рекламодатель принял ваш отклик, в меню в работе вы можете ознакомиться с текущими офферами в работе или задать вопрос рекламодателю.', reply_markup = bloger_menu)