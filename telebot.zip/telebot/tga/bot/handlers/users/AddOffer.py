from aiogram import types
from aiogram.dispatcher.filters import Command
import datetime

from loader import dp, bot
from sql import Offers
from keyboards.inline import create_offer


@dp.callback_query_handler(text='add_offer')
async def add(c):
  try:
    await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
    offers = Offers()
    if c.data == 'add_offer':
      text = f'Название: Пусто\n Тематика: Пусто\n Город: Пусто\n Начало: Пусто\n Конец: Пусто\n Минимальное число подписчиков: Пусто\n Текст задания: Пусто'
      await c.message.answer(f'Заполните все полля. \n {text}', reply_markup=create_offer)
  except:
    pass
    