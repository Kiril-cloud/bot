from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
import datetime

from loader import dp, bot
from keyboards.inline import offer, callback_kb
from sql import AddUsers, Offers, parser


@dp.callback_query_handler(text='avail_offers')
async def SendOffers(c):
  await bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  AU = AddUsers()
  offers = Offers()
  p = parser()
  username = AU.getBloger(c.from_user.id)
  follows = p.getFollow(username)
  names = AU.getOffer(follows)
  list_offer = InlineKeyboardMarkup(row_width=2)
  for name in names:
    res = offers.selectOffer(name)
    if res != 0:
      user = res[0]
      name = res[1]
      citi = res[2]
      theme = res[3]
      subs = res[4]
      start = res[5]
      stop = res[6]
      texts = res[7]
      text = f'#{user}\n#{name} \n Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
      await c.message.answer(text, reply_markup=callback_kb)