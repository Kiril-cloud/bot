import sqlite3
import os
from django.contrib import admin
from .models import ADS, Offers, Stats
from .forms import Offers, ADS, Blogers, Moder


def setCost(modeladmin, request, queryset):
  db = sqlite3.connect('tga/bot.db')
  sql = db.cursor()
  queryset.update(status = 1)
  sql.execute("INSERT INTO ugc_offers SELECT * FROM ugc_moder WHERE status = 1")
  sql.execute("DELETE FROM ugc_moder WHERE status = 1")
  db.commit()

setCost.short_description = "Одобрить оффер"


@admin.register(ADS)
class ADSAdmin(admin.ModelAdmin):
  list_display = ('user_id', 'status', 'date', 'offers')
  search_fields = ('user_id', 'date')
  

@admin.register(Offers)
class UsersAdmin(admin.ModelAdmin):
  list_display = ('user', 'name', 'online', 'theme', 'subs', 'start', 'stop', 'text', 'status', 'bloger', 'promo')
  
@admin.register(Blogers)
class BlogersAdmin(admin.ModelAdmin):
  list_display = ('user_id', 'status', 'date', 'phone', 'url')
  search_fields = ('user_id', 'date', 'url')
  
  
@admin.register(Moder)
class ModerAdmin(admin.ModelAdmin):
  list_display = ('user', 'name', 'online', 'theme', 'subs', 'start', 'stop', 'text', 'status', 'bloger', 'promo') 
  ordering = ['user']
  actions = [setCost]

@admin.register(Stats)
class Stats(admin.ModelAdmin):
  change_form_template = 'templates/admin/ugc/stats/change_list.html'
  azot = 1000
  list_display = ('new_users', 
  'old_users', 
  'moder_offers', 'active_offers', 
  'work_offer')