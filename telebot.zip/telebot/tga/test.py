import sqlite3


db = sqlite3.connect('tga/bot.db')
sql = db.cursor()

sql.execute("""SELECT * FROM ugc_ads""")
print(len(sql.fetchall()))
# db.commit()

# s = '587рекламодателей/88655блогера'
# print(s[s.rfind('/')+1 : -7])