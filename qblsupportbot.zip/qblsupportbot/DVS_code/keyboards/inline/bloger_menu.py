from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

bloger_menu = InlineKeyboardMarkup(row_width=1)
offers = InlineKeyboardButton('Посмотреть офферы', callback_data='avail_offers')
blog = InlineKeyboardButton('Oфферы в работе', callback_data='in_work')
bloger_menu.add(offers, blog)