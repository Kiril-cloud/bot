from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

compleet_kb = InlineKeyboardMarkup(row_width=1)
y = InlineKeyboardButton('Принять', callback_data='offer_compleeted')
n = InlineKeyboardButton('Oтклонить', callback_data='reject_result')
compleet_kb.add(y, n)