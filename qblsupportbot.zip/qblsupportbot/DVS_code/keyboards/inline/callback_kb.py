from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


callback_kb = InlineKeyboardMarkup(row_width=1)
take = InlineKeyboardButton('Откликнуться', callback_data='take')
callback_kb.add(take)