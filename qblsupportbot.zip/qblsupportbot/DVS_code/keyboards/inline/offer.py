from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

offer = InlineKeyboardMarkup(row_width=1)
add = InlineKeyboardButton('Новый оффер.', callback_data='add_offer')
list = InlineKeyboardButton('Список офферов', callback_data='list')
offer.add(add, list)