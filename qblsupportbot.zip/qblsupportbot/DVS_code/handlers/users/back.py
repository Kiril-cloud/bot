from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
from loader import dp
from keyboards.inline import offer


@dp.callback_query_handler(text='back')
async def back(c: CallbackQuery, state: FSMContext):
  if c.data == 'back':
    await state.finish()
    await c.message.answer('Выберите действие на клавиатуре ниже:', reply_markup = offer)