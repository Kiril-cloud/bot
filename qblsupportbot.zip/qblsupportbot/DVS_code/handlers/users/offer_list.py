from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
import datetime
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


from loader import dp, bot
from sql import Offers
from keyboards.inline import edit_offers, offer, work_kb
from states import offer_states


offer_state = offer_states()
offers = Offers()

@dp.callback_query_handler(text='list')
async def offer_list(c: CallbackQuery, state: FSMContext):
  offers = Offers()
  names = offers.getName(c.from_user.id)
  
  list_offer = InlineKeyboardMarkup(row_width=2)
  for name in names:
    name = InlineKeyboardButton(name, callback_data = name)
    list_offer.add(name)
  await c.message.answer('Вот список ваших офферов. Для редактирования нажмите на нужный вам оффер.', reply_markup = list_offer)
  
  

@dp.callback_query_handler()
async def offer_edit(c: CallbackQuery, state: FSMContext):
  try:
    offers = Offers()
    print(c.from_user.id)
    name = c.data
    if name == 'back':
      await state.finish()
      await c.message.answer('Выберите действие на клавиатуре ниже:', reply_markup = offer)
    else:
      ab = offers.owner(name, c.from_user.id)
      if ab == True:
        res = offers.getOffer(c.from_user.id, name)
        name = res[1]
        citi = res[2]
        theme = res[3]
        subs = res[4]
        start = res[5]
        stop = res[6]
        texts = res[7]
        text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
        await c.message.edit_text(f'Вот ваш оффер: \n {text}', reply_markup=edit_offers)
        
      elif ab == False:
        res = offers.selectOffer(c.data)
        user = res[0]
        name = res[1]
        citi = res[2]
        theme = res[3]
        subs = res[4]
        start = res[5]
        stop = res[6]
        texts = res[7]
        text = f'#{user}\n Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
        await c.message.edit_text(f'Вот информация по офферу: \n {text}', reply_markup=work_kb)
      
  except Exception as e:
    print(e)