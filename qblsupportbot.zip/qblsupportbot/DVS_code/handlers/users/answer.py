from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext

from loader import dp, bot
from states import work_st


w = work_st()


@dp.callback_query_handler(text='return')
async def answer(c):
  w = work_st()
  id = c.message.text.split()[0] + 'p'
  id = id[1 : -1]
  await c.message.answer(f'#{id}\n Отправте ответ на вопрос блогера, начните ваше сообщение с #{id}:')
  await w.return_answer.set()


@dp.message_handler(state=w.return_answer)
async def answer(message: types.message, state: FSMContext):
  try:
    await state.finish()
    id = message.text.split()[0] + 'p'
    id = id[1 : -1]
    await bot.send_message(id, message.text)
    await message.answer('Ваше ответ отправлен!')
  except:
    await message.answer('Неверный формат!')