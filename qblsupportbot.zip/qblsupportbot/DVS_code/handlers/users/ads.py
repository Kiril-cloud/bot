from aiogram import types
from aiogram.dispatcher.filters import Command
import datetime

from loader import dp
from keyboards.inline import offer
from sql import AddUsers


@dp.callback_query_handler(text='ads')
async def ads(c):
  try:
    add = AddUsers()
    if c.data == 'ads':
      try:
        add.AddADS(c.from_user.id, True, datetime.date.today())
      except:
        pass
      await c.message.edit_text('Отлично! Что вы хотите сделать:', reply_markup = offer )
  except Exception as e:
    print(e)
    

@dp.message_handler(commands = ['ads'])
async def adsMessage(message):
  try:
    add = AddUsers()
    try:
      add.AddADS(message.from_user.id, True, datetime.date.today())
    except:
      pass
    await message.answer('Что вы хотите сделать:', reply_markup = offer )
  except Exception as e:
    print(e)