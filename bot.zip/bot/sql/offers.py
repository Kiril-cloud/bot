import sqlite3
import os


class Offers():
  def __init__(self):
    self.db = sqlite3.connect("bot.db")
    self.sql = self.db.cursor()
    print(os.getcwd())
    try:
      self.sql.execute("CREATE TABLE ads(id, status, date, offers)")
      self.sql.execute("CREATE TABLE blogers(id, status, phone, email, date)")
      self.sql.execute("CREATE TABLE offers(id, name, online, theme, subs, start, stop, text, cost)")
      
    except Exception as e:
      print(e)
    
  def getOffer(self, id):
    self.sql.execute(f"""SELECT * FROM offers WHERE rowid == (SELECT MAX(rowid) FROM offers WHERE id == {id})""")
    result = self.sql.fetchone()
    names = str(result[1])
    citi = str(result[2])
    theme = str(result[3])
    subs = str(result[4])
    start = str(result[5])
    stop = str(result[6])
    texts = str(result[7])
    res = [0, names, citi, theme, subs, start, stop, texts]
    print(res)
    return res
    
  def setName(self, id, name, start):
    self.sql.execute(f"INSERT INTO offers VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)", (id, name, 'Пусто', 'Пусто', 'Пусто', start, 'Пусто', 'Пусто', 'Пусто'))
    self.db.commit()
    
  def setOnline(self, id, name, online):
    self.sql.execute(f"""UPDATE offers SET online = '{online}' WHERE id == {id} and name == '{name}' """)
    self.db.commit()
    
  def setTheme(self, id, name, theme):
    self.sql.execute(f"""UPDATE offers SET theme = '{theme}' WHERE id == {id} and name == '{name}' """)
    self.db.commit()
    
  def setSubs(self, id, name, subs):
    self.sql.execute(f"""UPDATE offers SET subs = '{subs}' WHERE id == {id} and name == '{name}' """)
    self.db.commit()
    
  def setStop(self, id, name, stop):
    self.sql.execute(f"""UPDATE offers SET stop = '{stop}' WHERE id == {id} and name == '{name}' """)
    self.db.commit()
    
  def setText(self, id, name, text):
    self.sql.execute(f"""UPDATE offers SET text = '{text}' WHERE id == {id} and name == '{name}' """)
    self.db.commit()
    
  def setCost(self, id, name, cost):
    self.sql.execute(f"""UPDATE offers SET cost = '{cost}' WHERE id == {id} and name == '{name}' """)
    self.db.commit()
    
  def getName(self, id):
    if id != 0:
      self.sql.execute(f"SELECT name FROM offers WHERE id = {id}")
    else:
      self.sql.execute(f"SELECT name FROM offers")
    names = self.sql.fetchall()
    out = []
    for name in names:
      out.append(name[0])
      
    return out