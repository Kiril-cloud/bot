import sqlite3
import datetime
from google_sheets import UserStats


class AddUsers():
  def __init__(self):
    self.db = sqlite3.connect("bot.db")
    self.sql = self.db.cursor()
    try:
      self.sql.execute("CREATE TABLE ads(id, status, date, offers)")
      self.sql.execute("CREATE TABLE blogers(id, status, phone, email, date)")
      self.sql.execute("CREATE TABLE offers(id, name, online, theme, subs, start, stop, text, cost)")
      
    except:
      pass
    
  def AddADS(self, id, status, date):
    US = UserStats()
    self.sql.execute(f"SELECT id FROM ads WHERE id == {id}")
    if self.sql.fetchone() == None:
      self.sql.execute("INSERT INTO ads VALUES(?, ?, ?, ?)", (id, status, date, 0))
      US.setAds(id, status, date, 0)
      self.db.commit()
      
  def setOffers(self, id):
    US = UserStats()
    self.sql.execute(f"SELECT offers FROM ads WHERE id == {id}")
    offers = self.sql.fetchone()[0]
    offers+=1
    self.sql.execute(f"UPDATE ads SET offers = {offers} WHERE id == {id}")
    US.setOffer(id, offers)
    self.db.commit()
    
  def AddBloger(self, id, status, phone, email, date):
    self.sql.execute(f"SELECT id FROM blogers WHERE id == {id}")
    if self.sql.fetchone() == None:
      self.sql.execute("INSERT INTO blogers VALUES(?, ?, ?, ?, ?)", (id, status, phone, email, date))
      self.db.commit()
      
  def getUsers(self):
    date = datetime.date.today() - datetime.timedelta(days=1)
    self.sql.execute(f"SELECT id FROM ads WHERE date > '{date}' ")
    new = len(self.sql.fetchall())
    self.sql.execute(f"SELECT id FROM ads WHERE date < '{date}' ")
    try:
      old = len(self.sql.fetchone())
    except:
      old = 0

    res = [new, old]
    return res
    
  def getActive(self):
    self.sql.execute("SELECT offers FROM ads")
    actives = self.sql.fetchall()
    out = 0
    print(list(actives))
    for active in list(actives):
      active = str(active)
      active = active.replace('(', '')
      active = active.replace(',', '')
      active = active.replace(')', '')
      active = active.replace('\'', '')
      active = int(active)
      if active > 0:
        out+=1
        print(out)
    return out