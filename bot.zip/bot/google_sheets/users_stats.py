import gspread
import sql
import datetime
import time

from loader import ban_list
from handlers.users import flud


class UserStats():
	def __init__(self):
		self.AU = sql.AddUsers()
		self.gc = gspread.service_account('sheets.json')
		self.sheet = self.gc.open('bot40')
		self.sh = self.sheet.worksheet('KPI пользователи')
		self.users = self.sheet.worksheet('Пользователи')
	
	def update(self):
	  i = (datetime.datetime.today() - datetime.datetime.strptime(self.sh.get('A2')[0][0], '%Y.%m.%d')).days
	  i+=2
	  print(i)
	  self.sh.update_acell('A'+str(i), str(datetime.date.today()))
	  self.sh.update_acell('C'+str(i), self.AU.getUsers()[1])
	  self.sh.update_acell('B'+str(i), int(self.AU.getUsers()[0]))
	  self.sh.update_acell('D'+str(i), self.AU.getActive())
	  
	def setAds(self, id, status, date, active):
	  try:
	    user = self.users.find(str(id))
	    row = user.row
	    self.users.update_acell('A' + str(row), id)
	    self.users.update_acell('B' + str(row), status)
	    self.users.update_acell('C' + str(row), date)
	    self.users.update_acell('D' + str(row), active)
	  except:
	    row = len(self.users.get_all_records()) + 2
	    self.users.update_acell('A' + str(row), id)
	    self.users.update_acell('B' + str(row), status)
	    self.users.update_acell('C' + str(row), str(date))
	    self.users.update_acell('D' + str(row), active)
	    
	def setOffer(self, id, offer):
	  try:
	    user = self.users.find(str(id))
	    row = user.row
	    self.users.update_acell('D' + str(row), offer)
	  except Exception as e:
	    print(e, 45)
	    
	async def setFlud(self, message):
	  try:
	    
	    flud_users = self.users.findall('FALSE')
	    for r in flud_users:
	      r = str(r)
	      r = r[7 : -11]
	      a = self.users.get('A' + str(r))
	      a = str(a)
	      a = a.replace('[', '')
	      a = a.replace(']', '')
	      a = a.replace('\'', '')
	      print(a)
	      try:
	        ban_list.append(int(a))
	        print(message.from_user.id)
	        if message.from_user.id == int(a):
	          await flud.ban(message)
	      except:
	        pass
	      
	    print(ban_list)
	  except Exception as e:
	    pass
	    
