from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart

from loader import dp
from states import step
from keyboards.inline import step1

Step = step()


@dp.message_handler(CommandStart())
async def bot_start(message: types.Message):
    await message.answer(f"""Привет, {message.from_user.full_name}, я бот куратор🤖
Я расскажу о преимуществах и правилах закрытой группы и канала.
А потом добавлю тебя  в туда ➕

Всего 3 шага и ты в чате!""", reply_markup=step1)
