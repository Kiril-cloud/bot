from aiogram import types
from aiogram.dispatcher.filters import Command

from loader import dp
from keyboards.inline import offer
from google_sheets import UserStats


@dp.callback_query_handler(text='blog')
async def ads(c):
  try:
    US = UserStats()
    if c.data == 'blog':
      await c.message.edit_text('Отлично!')
    else:
      return
  except:
    pass