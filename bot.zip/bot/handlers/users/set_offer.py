from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
import datetime

from loader import dp
from sql import Offers
from keyboards.inline import create_offer
from keyboards.inline import offer
from states import offer_states
from sql import AddUsers
from google_sheets import UserStats


offer_state = offer_states()

@dp.callback_query_handler(text=['name', 'online', 'theme', 'subs', 'stop', 'text'])
async def set_offer(c: CallbackQuery, state: FSMContext):
  try:
    US = UserStats()
    offer_state = offer_states()
    AU = AddUsers()
    if c.data == 'name':
      AU.setOffers(c.from_user.id)
      await offer_state.name.set()
      await c.message.edit_text('Введите название оффера:')
      
    if c.data == 'online':
      await offer_state.online.set()
      await c.message.edit_text('Ваш оффер можно выполнить не выходя из дома? Если да напишите онлайн, ели нет пришлите название города.')
      
    if c.data == 'theme':
      await offer_state.theme.set()
      await c.message.edit_text('Введите тематику оффера:')
    
    if c.data == 'subs':
      await offer_state.subs.set()
      await c.message.edit_text('Введите минимальное количество подписчиков у блогера чтобы он мог выполнить оффер:')
      
    if c.data == 'stop':
      await offer_state.stop.set()
      await c.message.edit_text('Введите дату окончания действия оффера:')
      
    if c.data == 'text':
      await offer_state.text.set()
      await c.message.edit_text('Введите текст задания оффера:')
      
    if c.data == 'back':
      await state.finish()
      await c.message.answer('Выберите действие на клавиатуре ниже:', reply_markup = offer)
  except:
    pass
    
@dp.message_handler(state=offer_state.name)
async def setName(message: types.message, state: FSMContext):
  try:
    US = UserStats()
    offers = Offers()
    offer_state = offer_states()
    await state.finish()
    offers.setName(message.from_user.id, message.text, datetime.datetime.today())
    
    res = offers.getOffer(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except:
    pass
  
  
@dp.message_handler(state=offer_state.online)
async def setCiti(message: types.message, state: FSMContext):
  try:
    US = UserStats()
    offers = Offers()
    offer_state = offer_states()
    data = await state.get_data()
    name = offers.getOffer(message.from_user.id)[1]
    await state.update_data(online=message.text)
    await state.finish()
    offers.setOnline(message.from_user.id, name, message.text)
    
    res = offers.getOffer(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except:
    pass
  
  
@dp.message_handler(state=offer_state.theme)
async def setTheme(message: types.message, state: FSMContext):
  try:
    US = UserStats()
    offers = Offers()
    offer_state = offer_states()
    data = await state.get_data()
    name = offers.getOffer(message.from_user.id)[1]
    await state.update_data(theme=message.text)
    await state.finish()
    offers.setTheme(message.from_user.id, name, message.text)
    
    res = offers.getOffer(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except:
    pass
  
@dp.message_handler(state=offer_state.subs)
async def setSubs(message: types.message, state: FSMContext):
  try:
    US = UserStats()
    offers = Offers()
    offer_state = offer_states()
    data = await state.get_data()
    name = offers.getOffer(message.from_user.id)[1]
    await state.update_data(subs=message.text)
    await state.finish()
    offers.setSubs(message.from_user.id, name, message.text)
    
    res = offers.getOffer(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except:
    pass
  
@dp.message_handler(state=offer_state.stop)
async def setStop(message: types.message, state: FSMContext):
  try:
    US = UserStats()
    offers = Offers()
    offer_state = offer_states()
    data = await state.get_data()
    name = offers.getOffer(message.from_user.id)[1]
    await state.update_data(stop=message.text)
    await state.finish()
    offers.setStop(message.from_user.id, name, message.text)
    
    res = offers.getOffer(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except:
    pass
  
@dp.message_handler(state=offer_state.text)
async def setText(message: types.message, state: FSMContext):
  try:
    US = UserStats()
    offers = Offers()
    offer_state = offer_states()
    data = await state.get_data()
    name = offers.getOffer(message.from_user.id)[1]
    await state.update_data(text=message.text)
    await state.finish()
    offers.setText(message.from_user.id, name, message.text)
    
    res = offers.getOffer(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except:
    pass