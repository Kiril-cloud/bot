from aiogram import types
from aiogram.dispatcher.filters import Command
import datetime

from loader import dp
from keyboards.inline import offer
from sql import AddUsers
from google_sheets import UserStats


@dp.callback_query_handler(text='ads')
async def ads(c):
  try:
    US = UserStats()
    add = AddUsers()
    if c.data == 'ads':
      add.AddADS(c.from_user.id, True, datetime.date.today())
      await c.message.edit_text('Отлично! Что вы хотите сделать:', reply_markup = offer )
    else:
      return
  except Exception as e:
    print(e)